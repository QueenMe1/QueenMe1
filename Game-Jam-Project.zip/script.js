let catcher; 
let potion;
let score = 0;
let backgroundImg;
let catcher1;
let Potion1;

/* PRELOAD LOADS FILES */
function preload(){
  backgroundImg = loadImage("assets/roadImage.jpg");
  catcher1 = loadImage("assets/catcher1.png");
  catcher2 = loadImage("assets/catcher1.png");
  catcher3 = loadImage("assets/catcher1.png");
  Boss1 = loadImage("assets/potion1.png");
  Potion1 = loadImage("assets/potion1.png");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400,400);
  //resize image
  backgroundImg.resize(0,400);
  catcher1.resize(70,60);
  Potion1.resize(30,50);
  
  
  
  //Create catcher 
  catcher = new Sprite(catcher1,200,360,100,20);
  catcher.collider = "kinematic";
  catcher.color = color(95,158,160);
  
  //Create falling object
  potion = new Sprite(Potion1,100,0,10);
  potion.collider = "d";
  potion.color = color(0,128,128);
  potion.y = 10;
  potion.vel.y = random(2,4);
}

/* DRAW LOOP REPEATS */
function draw() {
  background(224,224,224);

  image(backgroundImg, 0, 0);
  // Draw directions to screen
  fill(0);
  textSize(12);
  text("Move the \ncatcher with the \nleft and right \narrow keys to \ncatch the falling \nobjects.", width-100, 20);
  
    //If fallingObject reaches bottom, move back to random position at top
  if (potion.y >= 400) {
    potion.y = random(height / 2);
    potion.x = random(width);
    potion.vel.y = random(2,4);  

    //mild
    score = score - 1;
  }

  //Move catcher
  if (kb.pressing("space")) {
    catcher.vel.y = -3;
  } else if (kb.pressing("right")) {
    catcher.vel.x = 3;
  } else if (kb.pressing("left")){
    catcher.vel.x=-3;
  } else {
    catcher.vel.x = 0;
    catcher.y = 360;
  }
  

  //Stop catcher at edges of screen
  if (catcher.x < 50) {
    catcher.x = 50;
  } else if (catcher.x > 350) {
    catcher.x = 350;
  } else if (catcher.y < 0) {
    catcher.y = 380;
  }

    //If fallingObject collides with catcher, move back to top
  if (potion.collides(catcher)) {
    potion.y = 0;
    potion.x = random(50,350);
    potion.vel.y = random(2,4);
    potion.direction = "down";
    score = score + 1;
  }
  if (score == 5){
    catcher1.resize(100,120);
    catcher.y = 340;
  } else if (score ==  10){
    catcher1.resize(120,150);
    catcher.y = 330;
  }else if(score == 14){
    catcher1.resize(140,170);
    catcher.y = 310;
  }

  // Draw the score to screen
  fill(44,75,90);
  textSize(20);
  text("Score = " + score, 10, 30);

  //Medium - If score is less then zero, you lose
  if (score < 0) {
    background(224,224,224);
    
    //Draw sprites off of screen
    catcher.pos = { x: 600, y: -300 };
    potion.pos = { x: -100, y: 0 };
    
    //Draw end of game text
    textSize(20);
    fill(3);
    text("You lose!", width/2 - 50, height/2 - 30); 
    
  }
  if (score == 15) {
    youWin();

    // Restart the game if player clicks the mouse
    if (mouseIsPressed) {
      restart();
    }
  }
}

/* FUNCTIONS */

//Spicy
function youWin() {
  background(224,224,224);
  
  //Draw sprites off of screen
  catcher.pos = { x: 600, y: -300 };
  potion.pos = { x: -100, y: 0 };

  //Draw end of game text
  textSize(20);
  fill(0);
  text("You win!", width/2 - 50, height/2 - 30); 
  textSize(12);
  text("Click the mouse anywhere to play again.", width/2 - 120, height/2);
}

//Spicy 
function restart() {
  //Reset score
  score = 0;

  //Reset sprites
  catcher.pos = { x: 200, y: 380 };
  potion.y = 0;
  potion.x = random(50,350);
  potion.velocity.y = random(2,4);
  potion.direction = "down";
}
